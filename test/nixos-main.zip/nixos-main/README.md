# nixOS homelab

WIP
