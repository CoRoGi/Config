-- Left items
require("items.apple")
require("items.menu_spaces_toggle")
require("items.menus")
require("items.spaces")
require("items.front_apps")

-- Right items
require("items.message")
require("items.widgets")

-- require("items.media")
