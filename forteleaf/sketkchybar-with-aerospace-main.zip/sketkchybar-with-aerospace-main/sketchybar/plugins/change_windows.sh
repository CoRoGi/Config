#!/bin/bash

echo change_windows.sh NAME: $NAME, SENDER: $SENDER >> ~/aaaa
