# Reference link
https://github.com/hbthen3rd/dotfiles/tree/master/.config/sketchybar

